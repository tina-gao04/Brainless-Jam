extends Node2D

@export var fish_scene: PackedScene
@export var fish_count = 200

func _ready():
	for i in range(fish_count):
		var fish = fish_scene.instantiate()
		fish.global_position = global_position + Vector2(
			randf_range(-150, 150),
			randf_range(-150, 150)
		)
		get_parent().add_child(fish)
